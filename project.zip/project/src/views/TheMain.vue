<template>
  <div class="title">
    <h1>本系统由李宇 李城杰共同创建，如有雷同，我们有权利追究法律责任</h1>
  </div>
</template>
